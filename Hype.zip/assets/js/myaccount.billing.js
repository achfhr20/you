$(document).ready(function() {
  $("#btnConfirm").click(function() {
    var xAddress = $("#Address").val();
    var xCity = $("#City").val();
    var xState = $("#State").val();
    var xZip = $("#Zip").val();
    var xPhone = $("#Phone").val();
    var xStart;
    if (xAddress === "") {
      xStart = false;
      document.getElementById("DivAddress").className = "textInput lap hasError";
    }
    if (xCity === "") {
      xStart = false;
      document.getElementById("DivCity").className = "textInput lap hasError";
    }
    if (xState === "") {
      xStart = false;
      document.getElementById("DivState").className = "textInput lap hasError";
    }
    if (xZip === "") {
      xStart = false;
      document.getElementById("DivZip").className = "textInput lap hasError";
    }
    if (xPhone === "") {
      xStart = false;
      document.getElementById("DivPhone").className = "textInput lap hasError";
    }
    if (xStart === false) {
      return false;
    } else {
      document.getElementById("loading").className = "hasSpinner";
    }

  })
  $("#Address").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivAddress").className = "textInput lap";
    } else {
      document.getElementById("DivAddress").className = "textInput lap hasError";
    }
  })
  $("#State").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivState").className = "textInput lap";
    } else {
      document.getElementById("DivState").className = "textInput lap hasError";
    }

  })
  $("#City").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivCity").className = "textInput lap";
    } else {
      document.getElementById("DivCity").className = "textInput lap hasError";
    }

  })
  $("#Zip").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivZip").className = "textInput lap ";
    } else {
      document.getElementById("DivZip").className = "textInput lap hasError";
    }

  })
  $("#Phone").keyup(function() {
    if ($(this).val().length !== "") {
      document.getElementById("DivPhone").className = "textInput lap";
    } else {
      document.getElementById("DivPhone").className = "textInput lap hasError";
    }

  })
})
