<?php
session_destroy();
require_once __DIR__ . '/function.php';
$api->redirect('index.php');
?>
