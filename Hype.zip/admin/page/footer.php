<div id="footer">
	Scampage by KuzuluyArt.
</div>
