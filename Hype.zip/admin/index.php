<?php
require_once __DIR__ . '/../function.php';

$actual_page = 'home';
if ($_GET['logout'])
{
	session_destroy();
}
?>
<?php require 'page/header.php'; ?>

<body>
	<div id="header">
		<div class="container">
			<img src="../assets/img/logo.png">
		</div>
	</div>

	<div id="main">
		<div id="tooltip_main"></div>

    <?php require 'page/sidebar.php'; ?>

		<div class="content">
			<div class="half-container">
				<div class="head">1000 Visitor</div>
				<table rules="all">
					<thead>
						<tr>
							<th width="120px" style="background-color:#EEE"></th>
							<th width="210px" style="background-color:#DDD"></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<th><span>Signin</span></th>
							<th>10</th>
						</tr>
						<tr>
							<th><span>Card</span></th>
							<th>10</th>
						</tr>
						<tr>
							<th><span>3D Secure</span></th>
							<th>10</th>
						</tr>
						<tr>
							<th><span>Billing</span></th>
							<th>10</th>
						</tr>
						<tr>
							<th><span>Bank</span></th>
							<th>10</th>
						</tr>
						<tr>
							<th><span>Identity</span></th>
							<th>10</th>
						</tr>
					</tbody>
				</table>
			</div>

			<div class="half-container">
				<div class="head">200 Blocker</div>
				<table rules="all">
					<thead>
						<tr>
							<th width="120px" style="background-color:#EEE"></th>
							<th width="210px" style="background-color:#DDD"></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<th><span>Session</span></th>
							<th>10</th>
						</tr>
						<tr>
							<th><span>Agent</span></th>
							<th>10</th>
						</tr>
						<tr>
							<th><span>IP</span></th>
							<th>10</th>
						</tr>
						<tr>
							<th><span>Hostname</span></th>
							<th>10</th>
						</tr>
						<tr>
							<th><span>Proxy</span></th>
							<th>10</th>
						</tr>
						<tr>
							<th><span>Port</span></th>
							<th>10</th>
						</tr>

					</tbody>
				</table>
			</div>
			<div class="clear"></div>

			<div class="full-container">
				<ul id="list-main">
					<li>
						<span>Account</span>
						<div class="status on">1000</div>
					</li>
					<li>
						<span>Card</span>
						<div class="status on">90</div>
					</li>
					<li>
						<span>3D Secure</span>
						<div class="status on">100</div>
					</li>
					<li>
						<span>Bank</span>
						<div class="status on">9</div>
					</li>
					<li>
						<span>Identity</span>
						<div class="status on">8</div>
					</li>
				</ul>
			</div>
		</div><div class="clear"></div>
	</div>

	<?php require 'page/footer.php'; ?>
</body>
</html>
